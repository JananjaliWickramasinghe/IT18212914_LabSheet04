package jananjali.notification;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class Registration extends AppCompatActivity {
EditText v1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);



        EditText v1 = (EditText)findViewById(R.id.editText3);
        Bundle bundle = getIntent().getExtras();
        String Name=  bundle.getString("NumberOne");
        TextView num1 = (TextView) findViewById(R.id.editText3);
        num1.setText(Name);


    }
}
